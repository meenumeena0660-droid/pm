---
name: Jaipur Blue Digital
colors:
  surface: '#f8f9ff'
  surface-dim: '#cbdbf5'
  surface-bright: '#f8f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eff4ff'
  surface-container: '#e5eeff'
  surface-container-high: '#dce9ff'
  surface-container-highest: '#d3e4fe'
  on-surface: '#0b1c30'
  on-surface-variant: '#434656'
  inverse-surface: '#213145'
  inverse-on-surface: '#eaf1ff'
  outline: '#737688'
  outline-variant: '#c3c5d9'
  surface-tint: '#004ced'
  primary: '#003ec7'
  on-primary: '#ffffff'
  primary-container: '#0052ff'
  on-primary-container: '#dfe3ff'
  inverse-primary: '#b7c4ff'
  secondary: '#495e8a'
  on-secondary: '#ffffff'
  secondary-container: '#b7ccfe'
  on-secondary-container: '#415681'
  tertiary: '#4a4f53'
  on-tertiary: '#ffffff'
  tertiary-container: '#62676b'
  on-tertiary-container: '#e2e6eb'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dde1ff'
  primary-fixed-dim: '#b7c4ff'
  on-primary-fixed: '#001452'
  on-primary-fixed-variant: '#0038b6'
  secondary-fixed: '#d8e2ff'
  secondary-fixed-dim: '#b1c6f9'
  on-secondary-fixed: '#001a42'
  on-secondary-fixed-variant: '#314671'
  tertiary-fixed: '#dfe3e8'
  tertiary-fixed-dim: '#c3c7cc'
  on-tertiary-fixed: '#171c20'
  on-tertiary-fixed-variant: '#42474b'
  background: '#f8f9ff'
  on-background: '#0b1c30'
  surface-variant: '#d3e4fe'
typography:
  display-lg:
    fontFamily: Inter
    fontSize: 64px
    fontWeight: '800'
    lineHeight: '1.1'
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Inter
    fontSize: 40px
    fontWeight: '800'
    lineHeight: '1.2'
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '700'
    lineHeight: '1.3'
  headline-md:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: '1.4'
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.6'
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.6'
  label-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: '1'
    letterSpacing: 0.05em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 8px
  container-max: 1280px
  gutter: 24px
  margin-mobile: 16px
  section-gap-desktop: 120px
  section-gap-mobile: 64px
---

## Brand & Style

The design system is engineered for a high-performance digital marketing agency. It balances the vibrant energy of Jaipur's tech scene with the rigorous professionalism required by enterprise clients. The aesthetic is **Corporate Modern** with a focus on high-clarity information architecture and conversion-oriented layouts.

The visual narrative prioritizes trust and results. It utilizes generous whitespace, crisp structural alignment, and subtle technical accents to evoke an atmosphere of precision and reliability. The interface should feel organized, fast, and authoritative, ensuring that data and case studies remain the focal point.

## Colors

The palette is anchored by a high-intensity "Energetic Blue" that drives action and highlights key CTAs. This is balanced by a "Professional Navy" used for typography and structural elements to ground the design in stability.

- **Primary (Energetic Blue):** Used for primary buttons, active states, and critical brand moments.
- **Secondary (Professional Navy):** Used for headings, navigation backgrounds, and deep footer sections.
- **Surface (Clean White):** The primary canvas color to maintain a breathable, modern feel.
- **Neutral:** A range of slate grays used for body text, borders, and secondary metadata.

## Typography

The design system exclusively utilizes **Inter** to achieve a systematic, utilitarian aesthetic. The type scale is aggressive in its hierarchy to guide the user’s eye quickly to value propositions.

- **Headlines:** Use tight letter-spacing and heavy weights (Bold/ExtraBold) to project confidence.
- **Body:** Opt for the "Regular" weight with generous line-height to ensure maximum readability for long-form case studies.
- **Labels:** Small caps or uppercase with increased tracking should be used for overlines and categorization tags.

## Layout & Spacing

The design system employs a **12-column fluid grid** for desktop and a **4-column grid** for mobile. A strict 8px spacing scale governs all internal padding and margins to maintain mathematical harmony.

- **Vertical Rhythm:** Large sections (Hero, Services, Testimonials) are separated by significant vertical gaps to prevent visual clutter and allow the user to digest one concept at a time.
- **Alignment:** Content should predominantly be left-aligned to mimic professional editorial standards, with center-alignment reserved for high-impact hero statements.

## Elevation & Depth

This design system uses a **Tonal Layering** approach combined with **Ambient Shadows**. Instead of heavy borders, depth is created by placing white surfaces over light gray backgrounds (`#F8FAFC`).

- **Interactive Elements:** Buttons and cards should feature a very soft, diffused shadow (Blur: 20px, Opacity: 8%, Color: Navy) that intensifies slightly on hover to provide tactile feedback.
- **Flat Overlays:** Use 1px borders in a very light neutral shade (`#E2E8F0`) for secondary containers where shadow-based elevation would feel too heavy.

## Shapes

The shape language is "Rounded" to soften the corporate edge and appear more approachable. 

- **Components:** Standard buttons and input fields use a `0.5rem` radius. 
- **Cards & Sections:** Large containers and feature cards use `1rem` (rounded-lg) to create a distinct frame for content. 
- **Accents:** Occasional use of "Pill" shapes for status chips and tags to contrast against the more structured rectangular grid.

## Components

### Buttons
- **Primary:** Solid "Energetic Blue" with white text. High-contrast, 16px horizontal padding, Bold weight.
- **Secondary:** Transparent background with a 2px "Professional Navy" border.

### Cards
- Case study cards should feature a large image header with a 1:1.5 aspect ratio, followed by a headline and a small "view project" text link with a trailing arrow icon.

### Input Fields
- Modern, "Floating Label" style with a 1px border. The border shifts to "Energetic Blue" on focus to provide clear visual confirmation of user intent.

### Additional Components
- **Stat Counters:** Large numerical displays (Display-LG) with a small label below, used for highlighting agency KPIs (e.g., "500% ROI").
- **Trust Bar:** A horizontal scrolling or static list of monochrome client logos, set to 30% opacity, returning to full color on hover.